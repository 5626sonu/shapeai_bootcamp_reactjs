import React from "react";
function info() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        a basic web development React.js bootcamp.taken by Shaurya sinha.It was
        an amazing bootcamp very useful
      </p>
    </div>
  );
}
export default info;
