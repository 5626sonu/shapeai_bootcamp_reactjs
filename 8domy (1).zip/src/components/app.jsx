import react from "react";
function App() {
  return (
    <div>
      <header />
      <footer />
      <info />
      <info />
    </div>
  );
}
export default App;
