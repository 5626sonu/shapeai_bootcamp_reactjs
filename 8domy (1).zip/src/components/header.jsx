import React from "react";

function header() {
  return (
    <header>
      <h1>ShapeAI Bootcamp</h1>
    </header>
  );
}
export default header;
